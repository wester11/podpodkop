import { svgEl } from '../helpers';

export function renderRotateCcwIcon24() {
  const NS = 'http://www.w3.org/2000/svg';
  return svgEl(
    'svg',
    {
      xmlns: NS,
      viewBox: '0 0 24 24',
      fill: 'none',
      stroke: 'currentColor',
      'stroke-width': '2',
      'stroke-linecap': 'round',
      'stroke-linejoin': 'round',
      class: 'lucide lucide-rotate-ccw-icon lucide-rotate-ccw',
    },
    [
      svgEl('path', {
        d: 'M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8',
      }),
      svgEl('path', {
        d: 'M3 3v5h5',
      }),
    ],
  );
}
